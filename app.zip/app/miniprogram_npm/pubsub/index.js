module.exports = (function() {
var __MODS__ = {};
var __DEFINE__ = function(modId, func, req) { var m = { exports: {}, _tempexports: {} }; __MODS__[modId] = { status: 0, func: func, req: req, m: m }; };
var __REQUIRE__ = function(modId, source) { if(!__MODS__[modId]) return require(source); if(!__MODS__[modId].status) { var m = __MODS__[modId].m; m._exports = m._tempexports; var desp = Object.getOwnPropertyDescriptor(m, "exports"); if (desp && desp.configurable) Object.defineProperty(m, "exports", { set: function (val) { if(typeof val === "object" && val !== m._exports) { m._exports.__proto__ = val.__proto__; Object.keys(val).forEach(function (k) { m._exports[k] = val[k]; }); } m._tempexports = val }, get: function () { return m._tempexports; } }); __MODS__[modId].status = 1; __MODS__[modId].func(__MODS__[modId].req, m, m.exports); } return __MODS__[modId].m.exports; };
var __REQUIRE_WILDCARD__ = function(obj) { if(obj && obj.__esModule) { return obj; } else { var newObj = {}; if(obj != null) { for(var k in obj) { if (Object.prototype.hasOwnProperty.call(obj, k)) newObj[k] = obj[k]; } } newObj.default = obj; return newObj; } };
var __REQUIRE_DEFAULT__ = function(obj) { return obj && obj.__esModule ? obj.default : obj; };
__DEFINE__(1656054823361, function(require, module, exports) {


var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * Creates a new PubSubClass.
 * @class
 */

var PubSubClass = function () {
  /**
   * @constructs PubSubClass
   */

  function PubSubClass() {
    _classCallCheck(this, PubSubClass);

    this.channels = {};
    this.flags = {
      crossTabEnabled: false,
      historyEnabled: false,
      historyLength: 15
    };
    this.id = this._uuid();
  }

  /**
    * Generate uuid.
    * @function _uuid
    * @returns {string} - returns new uuid
   */


  _createClass(PubSubClass, [{
    key: '_uuid',
    value: function _uuid() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : r & 0x3 | 0x8;
        return v.toString(16);
      });
    }

    /**
     * Write history to a channel
     * @function _writeHistory
     * @param {object} message - message to write
     * @param {string} channel - the channel to write history to
    */

  }, {
    key: '_writeHistory',
    value: function _writeHistory(message, channel) {
      // If history is enabled, store message in history.
      if (this.flags.historyEnabled) {
        this.channels[channel].history.push({
          message: message,
          time: Date.now()
        });

        if (this.channels[channel].history.length > this.flags.historyLength) {
          this.channels[channel].history.shift();
        }
      }
    }

    /**
      * Set flags
      * @function setFlag
     */

  }, {
    key: 'setFlag',
    value: function setFlag(flag, value) {
      switch (flag) {
        case 'crossTabEnabled':
          if (window) this.flags.crossTabEnabled = value;
          break;
        case 'historyEnabled':
          this.flags.historyEnabled = value;
          break;
        case 'historyLength':
          this.flags.historyLength = value;
          break;
        default:
          break;
      }
    }

    /**
      * Join a channel
      * @function join
      * @param {string} channel - the channel to join
      * @param {function} handler - the function to send messages to.
     */

  }, {
    key: 'join',
    value: function join(channel, handler) {
      var _this = this;

      var uuid = this._uuid();
      handler(false, uuid);

      // If the channel doesn't exist, create it.
      if (!this.channels[channel]) {
        this.channels[channel] = {
          clients: {},
          history: []
        };
      }

      // If cross tab is enabled, listen for cross tab messages
      if (this.flags.crossTabEnabled) {
        window.addEventListener('storage', function (e) {
          if (e.key === 'PubSub-' + channel) {
            var payload = JSON.parse(e.newValue);
            if (payload.id != _this.id) {
              handler(payload.message, uuid);
              _this._writeHistory(payload.message, channel);
            }
          }
        }, false);
      }

      // Add our new client
      this.channels[channel].clients[uuid] = handler;

      return this;
    }

    /**
      * Leave a channel
      * @function leave
      * @param {string} channel - the channel to leave
      * @param {string} uuid - the uuid of the client who should leave
      * @returns {promise} - returns new promise, resolved when client leaves
     */

  }, {
    key: 'leave',
    value: function leave(channel, uuid) {
      var _this2 = this;

      return new Promise(function (resolve) {
        // Once we leave a channel, set our handler to a noop.
        _this2.channels[channel].clients[uuid] = function () {/*noop*/};
        resolve();
      });
    }

    /**
     * Get history from a channel
     * @function history
     * @param {string} channel - the channel to leave
     * @param {number} limit - how many messages from history
     * @returns {array} - returns history from channel
    */

  }, {
    key: 'history',
    value: function history(channel) {
      var limit = arguments.length <= 1 || arguments[1] === undefined ? 15 : arguments[1];

      return this.channels[channel].history.slice(0, limit);
    }

    /**
      * Publish a message to channel
      * @function publish
      * @param {string} channel - the channel to publish to
      * @param {object} message - the message to publish
      * @returns {promise} - returns new promise, resolved when message is sent to all clients
     */

  }, {
    key: 'publish',
    value: function publish(channel, message) {
      var _this3 = this;

      // If crossTab is enabled, dispatch message to app PubSub instances.
      if (this.flags.crossTabEnabled) {
        localStorage.setItem('PubSub-' + channel, JSON.stringify({
          message: message,
          time: Date.now(),
          from: this.id
        }));
      }

      this._writeHistory(message, channel);

      return new Promise(function (resolve) {
        // Send message to all subscribers.
        Object.keys(_this3.channels[channel].clients).map(function (client, i) {

          // Displatch message to client.
          _this3.channels[channel].clients[client](message, client);

          // Once we're done, resole the promise letting us know.
          if (Object.keys(_this3.channels[channel].clients).length - 1 === i) {
            resolve();
          }
        });
      });
    }
  }]);

  return PubSubClass;
}();

;

// Bind to global scope for easy access
if (typeof global != 'undefined') {
  global.PubSub = new PubSubClass();
} else {
  window.PubSub = new PubSubClass();
}

}, function(modId) {var map = {}; return __REQUIRE__(map[modId], modId); })
return __REQUIRE__(1656054823361);
})()
//miniprogram-npm-outsideDeps=[]
//# sourceMappingURL=index.js.map