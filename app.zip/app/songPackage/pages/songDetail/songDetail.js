// pages/songDetail/songDetail.js
import PubSub from 'pubsub-js'
import moment from 'moment'
import request from '../../../utils/request'
const appInstance = getApp();
Page({

  /**
   * 页面的初始数据
   */ 
  data: {
    isPlay: true,
    song: {},
    musicLink: '',
    musicId: "",
    currentTime:'00:00',//实际时间
    durationTime:'00:00',//总时长
    currentWidth:0,//实时进度条的宽度
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let musicId = options.musicId;
    this.setData({
      musicId
    })
    
    if (appInstance.globalData.isMusicPlay && appInstance.globalData.musicId === musicId) {
      this.setData({
        isPlay: true
      })
    }

    this.getMusicInfo(musicId);
    // 创建控制音乐播放实例
    this.backgroundAudioManager = wx.getBackgroundAudioManager();
    // 监视背景音乐播放状态
    this.backgroundAudioManager.onPlay(() => {
      this.changePlayState(true);
      appInstance.globalData.musicId = musicId
    })
    this.backgroundAudioManager.onPause(() => {
      this.changePlayState(false);
    });
    this.backgroundAudioManager.onStop(() => {
      this.changePlayState(false);
    })
    // 音乐播放自然结束
    this.backgroundAudioManager.onEnded(() => {
      PubSub.publish('switchType','next') 
      this.setData({
        currentWidth:0,
        currentTime:'00:00'
      })
    })

    this.backgroundAudioManager.onTimeUpdate(()=>{
      let currentTime=moment(this.backgroundAudioManager.currentTime * 1000).format('mm:ss');
      let currentWidth = this.backgroundAudioManager.currentTime / this.backgroundAudioManager.duration * 450;
      console.log(currentWidth)
      this.setData({
        currentTime,
        currentWidth
      })
    })
  },
  changePlayState(isPlay) {
    this.setData({
      isPlay
    })
    appInstance.globalData.isMusicPlay = isPlay;

  },

  async getMusicInfo(musicId=1387581250) {
    let songData = await request('/song/detail', { ids: musicId });
    console.log(songData)
    let durationTime=moment(songData.songs[0].dt).format('mm:ss');
    this.setData({
      song: songData.songs[0],
      durationTime
    })

    wx.setNavigationBarTitle({
      title: songData.songs[0].name,
    })

    this.musicControl(true,musicId)
  },


  // 控制暂停播放
  handleMusicPlay() {
    this.setData({
      isPlay: !this.data.isPlay
    })
    this.musicControl(this.data.isPlay,this.data.musicId,this.data.musicLink);
  },


  // 控制音乐播放/暂停函数
  async musicControl(isPlay,musicId,musicLink) {

    if (isPlay) {
      // 获取音乐播放链接
      if(!musicLink){
        let musicLinkData=await request('/song/url', { id: musicId })
        musicLink =musicLinkData.data[0].url;
        this.setData({
          musicLink,
        })
        
      }
      
      this.backgroundAudioManager.src =  musicLink;
      this.backgroundAudioManager.title = this.data.song.name;
    } else {
      // 暂停音乐
      this.backgroundAudioManager.pause();
    }
  },

  // 点击切歌的回调
  handleSwitch(event){
    // 获取切歌的类型
    let type = event.currentTarget.id;
    
    this.backgroundAudioManager.stop();

    PubSub.subscribe('musicId',(msg,musicId)=>{
      console.log(musicId);

      // 更新音乐详情
      this.getMusicInfo(musicId);
      this.musicControl(true,musicId);

      //取消订阅
      PubSub.unsubscribe('musicId');
    })

    // 发布消息给recommendSong
    PubSub.publish('switchType',type)
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})